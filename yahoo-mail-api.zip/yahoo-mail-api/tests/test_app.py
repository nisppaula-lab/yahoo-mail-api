import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ.setdefault("YAHOO_EMAIL", "user@example.com")
os.environ.setdefault("YAHOO_APP_PASSWORD", "app-password")
os.environ.setdefault("API_TOKEN", "test-token")

import app

class TestHelpers(unittest.TestCase):
    def test_constant_time_equal(self):
        self.assertTrue(app.constant_time_equal("abc", "abc"))
        self.assertFalse(app.constant_time_equal("abc", "abd"))
        self.assertFalse(app.constant_time_equal("abc", "abcd"))

    def test_clean_text(self):
        self.assertEqual(app.clean_text("  a\n\n b\t c ", 20), "a b c")

    def test_parse_message_snippet(self):
        raw = b"From: Sender <s@example.com>\r\nTo: user@example.com\r\nSubject: Hello World\r\nDate: Wed, 08 Oct 2026 10:00:00 -0400\r\nContent-Type: text/plain; charset=utf-8\r\n\r\nThis is the message body with enough text for a snippet."
        item = app.parse_message(raw, "123", "INBOX", include_full=False)
        self.assertEqual(item["subject"], "Hello World")
        self.assertIn("message body", item["snippet"])
        self.assertFalse(item["hasAttachments"])

if __name__ == "__main__":
    unittest.main()
